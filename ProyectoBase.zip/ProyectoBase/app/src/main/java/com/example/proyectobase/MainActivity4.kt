package com.example.proyectobase

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.proyectobase.utils.OpMath


class MainActivity4 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main4)

        val numeroUno: EditText = findViewById(R.id.ed_opUno)
        val numeroDos: EditText = findViewById(R.id.ed_opDos)
        val txResultado: TextView = findViewById(R.id.tx_resultado_act4)
        val btnCalcular: Button = findViewById(R.id.btn_calcular)

        val spoperaciones:Spinner = findViewById(R.id.operaciones)

        //array de elementos para cargar el spinner
        val menuOpciones = arrayOf("Sumar","Restar","Multiplicar","Dividir")

        //crearemos un adaptador
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1,menuOpciones)

        //asignamos al spinner
        spoperaciones.adapter = adapter

        // boton calcular
        btnCalcular.setOnClickListener {
            var valorNumeroUno: Int = numeroUno.text.toString().toIntOrNull()
            var valorNumeroDos: Int = numeroDos.text.toString().toIntOrNull()

            var resultado
        }




        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}