package com.example.proyectobase.utils

object OpMath {
    fun dividir(valor1: Int, valor2: Int):Int{
        return valor1/valor2
    }
}